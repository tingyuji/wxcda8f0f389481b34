Component({
    properties: {
        navH: String,
        origin: String
    },
    data: {
        title: ""
    },
    methods: {
        navBack: function() {
            this.data.origin ? wx.navigateTo({
                url: "../../pages/index/index"
            }) : wx.navigateBack();
        }
    }
});