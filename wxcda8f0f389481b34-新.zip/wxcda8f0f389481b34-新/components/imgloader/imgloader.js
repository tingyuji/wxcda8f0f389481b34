Component({
    properties: {},
    data: {
        imgInfo: {},
        callbacks: {},
        imgLoadList: []
    },
    methods: {
        imgLoad: function(t) {
            var a = t.currentTarget.dataset.src, i = t.detail.width, s = t.detail.height;
            this.data.imgInfo[a] = {
                width: i,
                height: s
            }, this._removeFromLoadList(a), this._runCallback(null, {
                src: a,
                width: i,
                height: s
            });
        },
        imgFail: function(t) {
            var a = t.currentTarget.dataset.src;
            this._removeFromLoadList(a), this._runCallback("Loading failed", {
                src: a
            });
        },
        _removeFromLoadList: function(t) {
            var a = this.data.imgLoadList;
            a.splice(a.indexOf(t), 1), this.setData({
                imgLoadList: a
            });
        },
        load: function(t, a) {
            if (t) {
                var i = this.data.imgLoadList, s = this.data.imgInfo[t];
                a && (this.data.callbacks[t] = a), s ? this._runCallback(null, {
                    src: t,
                    width: s.width,
                    height: s.height
                }) : (i.push(t), this.setData({
                    imgLoadList: i
                }));
            }
        },
        _runCallback: function(t, a) {
            (0, this.data.callbacks[a.src])(t, a), delete this.data.callbacks[a.src];
        }
    }
});