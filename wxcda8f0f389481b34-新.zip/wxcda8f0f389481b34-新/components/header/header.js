Component({
    data: {},
    methods: {
        hideheader: function() {}
    }
});