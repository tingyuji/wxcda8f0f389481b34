App({
    onLaunch: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(a) {
                t.globalData.navHeight = a.statusBarHeight + 8;
            },
            fail: function(t) {
                console.log(t);
            }
        });
        try {
            var a = wx.getStorageSync("config");
            a && (this.globalData.config = a);
        } catch (t) {}
    },
    globalData: {
        userInfo: null,
        navHeight: 0,
        config: {
            useVoice: !0,
            useShake: !0,
            useCache: !0,
            sportRatio: "6:4"
        }
    }
});