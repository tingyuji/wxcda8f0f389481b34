var t = getApp();

Page({
    data: {
        game: {
            name: "叮咚决策器",
            tips: "点击按钮开始掷骰子",
            start: "掷骰子"
        },
        showDefault: !0,
        setdices: [ "active", "default", "default" ],
        dicnum: [ {
            id: 0,
            src: "/imges/dice/dice1.png"
        } ],
        cup_animation: "",
        pending: !1,
        dicesrc: "https://zm-1253465948.cos.ap-nanjing.myqcloud.com/static/dd/dice.mp3"
    },
    onLoad: function(i) {
        this.setData({
            navH: t.globalData.navHeight,
            config: t.globalData.config
        }), this.selectComponent("#header").hideheader(), this.animate("#cont", [ {
            top: "33.5%",
            ease: "ease-in-out"
        }, {
            top: "10.5%",
            ease: "ease-in-out"
        } ], 300, function() {}.bind(this)), null != i && i.origin && this.setData({
            origin: null == i ? void 0 : i.origin
        }), t.globalData.config.useVoice && (this.audioctx = wx.createInnerAudioContext(), 
        this.audioctx.src = this.data.dicesrc);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "不要纠结啦，叮咚决策器帮你做决定!",
            imageUrl: "/imges/share-home.png"
        };
    },
    onShareTimeline: function() {
        return {
            title: "不要纠结啦，叮咚决策器帮你做决定!",
            query: "origin=dice",
            imageUrl: "/imges/share-home.png"
        };
    },
    diceSelect: function(t) {
        if (!this.data.pending) {
            var i = t.currentTarget.dataset.index, e = this.data.setdices, n = [];
            if ("active" !== e[i]) {
                (e = [ "default", "default", "default" ])[i] = "active";
                for (var a = 0; a <= i; a++) n.push({
                    id: a,
                    src: "/imges/dice/dice1.png"
                });
                this.setData({
                    setdices: e,
                    dicnum: n
                });
            }
        }
    },
    vibrateLong: function() {
        this.data.config.useShake && wx.vibrateLong();
    },
    vibrateShort: function() {
        this.data.config.useShake && wx.vibrateShort();
    },
    clickbtn: function(t) {
        var i = this;
        if (!this.data.pending) {
            this.vibrateShort();
            this.setData({
                cup_animation: "cup_animation",
                pending: !0
            }), setTimeout(function() {
                i.audioctx && i.audioctx.play();
            }, 800), setTimeout(function() {
                var t = i.data.dicnum;
                t.forEach(function(t, i) {
                    var e = parseInt(6 * Math.random(0, 1) + 1);
                    t.src = "/imges/dice/dice".concat(e, ".png");
                }), i.setData({
                    dicnum: t
                }), i.vibrateLong();
            }, 2300), setTimeout(function() {
                i.setData({
                    cup_animation: "",
                    pending: !1
                });
            }, 3100);
        }
    }
});