var t = getApp();

Page({
    data: {
        game: {
            name: "叮咚决策器",
            tips: "点击按钮开始抛硬币",
            start: "抛硬币"
        },
        answer: "",
        imgsrc: "",
        showDefault: !0,
        coin_animation: "",
        showRight: !1,
        showReverse: !1,
        gifsrc: {
            right: "https://zm-1253465948.cos.ap-nanjing.myqcloud.com/static/dd/coin_right.png",
            reverse: "https://zm-1253465948.cos.ap-nanjing.myqcloud.com/static/dd/coin_reverse.png"
        },
        coinsrc: "https://zm-1253465948.cos.ap-nanjing.myqcloud.com/static/dd/coin.mp3",
        gifpools: {},
        lastanswer: "",
        pending: !1
    },
    onLoad: function(i) {
        this.setData({
            navH: t.globalData.navHeight,
            config: t.globalData.config
        }), this.animate("#cont", [ {
            top: "33.5%",
            ease: "ease-in-out"
        }, {
            top: "10.5%",
            ease: "ease-in-out"
        } ], 300, function() {}.bind(this)), null != i && i.origin && this.setData({
            origin: null == i ? void 0 : i.origin
        }), t.globalData.config.useVoice && (this.videoContext = wx.createVideoContext("myVideo"), 
        this.audioctx = wx.createInnerAudioContext(), this.audioctx.src = this.data.coinsrc);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "不要纠结啦，叮咚决策器帮你做决定!",
            imageUrl: "/imges/share-home.png"
        };
    },
    onShareTimeline: function() {
        return {
            title: "不要纠结啦，叮咚决策器帮你做决定!",
            query: "origin=coin",
            imageUrl: "/imges/share-home.png"
        };
    },
    vibrateLong: function() {
        this.data.config.useShake && wx.vibrateLong();
    },
    vibrateShort: function() {
        this.data.config.useShake && wx.vibrateShort();
    },
    clickbtn: function() {
        if (!this.data.pending) {
            this.setData({
                showRight: !1,
                showReverse: !1
            }), this.data.config.useShake && this.vibrateShort();
            var t = this, i = Math.floor(10 * Math.random(0, 1)), n = "";
            i >= 5 ? (n = "right", this.setData({
                showRight: !1,
                showReverse: !0
            })) : (n = "reverse", this.setData({
                showRight: !0,
                showReverse: !1
            })), this.setData({
                pending: !0,
                showDefault: !1,
                answer: "",
                lastanswer: n
            }), this.audioctx && this.audioctx.play(), setTimeout(function() {
                t.setData({
                    animation: "showanimate",
                    answer: "right" === n ? "正" : "反",
                    pending: !1
                }), t.vibrateLong();
            }, 1500);
        }
    }
});