var t = require("../../@babel/runtime/helpers/defineProperty"), e = getApp();

Page({
    data: {
        game: {
            name: "叮咚决策器",
            tips: "纠结今天运不运动？点击按钮帮你做决定",
            start: "今天运动吗",
            sport: "运动",
            rest: "休息",
            result_sport: "今天运动一下吧",
            result_rest: "今天就休息一下吧"
        },
        animate: "",
        disable: !1,
        sportVoice: "https://zm-1253465948.cos.ap-nanjing.myqcloud.com/static/dd/sport.mp3"
    },
    onLoad: function(a) {
        this.setData({
            navH: e.globalData.navHeight,
            config: e.globalData.config
        }), this.selectComponent("#header").hideheader(), null != a && a.origin && this.setData({
            origin: null == a ? void 0 : a.origin
        }), this.animate("#cont", [ {
            top: "33.5%",
            ease: "ease-in-out"
        }, {
            top: "10.5%",
            ease: "ease-in-out"
        } ], 300, function() {}.bind(this));
        try {
            var i = wx.getStorageSync("usesport");
            if (i) {
                var o = new Date(i.time), n = new Date();
                if (this.isSameDay(o, n)) {
                    var s, r = "";
                    r = "sport" === i.sport ? "showsport" : "showrest", this.setData((t(s = {
                        disable: !0
                    }, "game.start", "一天只能选择一次哦"), t(s, "animate", r), s));
                }
            }
        } catch (t) {}
        e.globalData.config.useVoice && (this.actx = wx.createInnerAudioContext(), this.actx.src = this.data.sportVoice);
    },
    isSameDay: function(t, e) {
        var a = new Date(t), i = new Date(e);
        return a.setHours(0, 0, 0, 0) == i.setHours(0, 0, 0, 0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "不要纠结啦，叮咚决策器帮你做决定!",
            imageUrl: "/imges/share-home.png"
        };
    },
    onShareTimeline: function() {
        return {
            title: "不要纠结啦，叮咚决策器帮你做决定!",
            query: "origin=sport",
            imageUrl: "/imges/share-home.png"
        };
    },
    vibrateShort: function() {
        this.data.config.useShake && wx.vibrateShort();
    },
    vibrateLong: function() {
        this.data.config.useShake && wx.vibrateLong();
    },
    clickbtn: function() {
        var a, i = this;
        if (!this.data.disable) {
            var o = e.globalData.config.sportRatio || "6:5", n = +o.split(":")[0], s = +o.split(":")[1], r = Math.floor(Math.random() * (n + s)) < n ? "sport" : "rest";
            this.vibrateShort(), this.actx && this.actx.play(), this.setData((t(a = {
                animate: r
            }, "game.start", "一天只能选择一次哦"), t(a, "disable", !0), a)), setTimeout(function() {
                i.vibrateLong();
            }, 3e3), wx.setStorageSync("usesport", {
                time: Date.now(),
                sport: r
            });
        }
    }
});