var t = require("../../@babel/runtime/helpers/defineProperty"), n = getApp();

Page({
    data: {
        game: {
            name: "叮咚决策器",
            tips: "设置参数后，点击按钮生成随机数",
            start: "随机数生成"
        },
        rank1: 1,
        rank2: 10,
        rank3: 3,
        ranklist: [ {
            content: "?",
            style: ""
        }, {
            content: "?",
            style: ""
        }, {
            content: "?",
            style: ""
        } ],
        pending: !1,
        result: "https://7a69-ziming-patwj-1303043907.tcb.qcloud.la/static/result.mp3?sign=39649a7924659a4c92fcea75b4df875e"
    },
    onLoad: function(t) {
        console.log(this), this.setData({
            navH: n.globalData.navHeight,
            config: n.globalData.config
        }), this.selectComponent("#header").hideheader(), null != t && t.origin && this.setData({
            origin: null == t ? void 0 : t.origin
        }), this.animate("#cont", [ {
            top: "33.5%",
            ease: "ease-in-out"
        }, {
            top: "10.5%",
            ease: "ease-in-out"
        } ], 300, function() {}.bind(this));
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "不要纠结啦，叮咚决策器帮你做决定!",
            imageUrl: "/imges/share-home.png"
        };
    },
    onShareTimeline: function() {
        return {
            title: "不要纠结啦，叮咚决策器帮你做决定!",
            query: "origin=random",
            imageUrl: "/imges/share-home.png"
        };
    },
    vibrateShort: function() {
        this.data.config.useShake && wx.vibrateShort();
    },
    bindKeyInput: function(n) {
        var e = n.currentTarget.dataset.id;
        if ("rank3" === e) {
            if (n.detail.value > 10 || n.detail.value < 1) return console.log("超出范围"), void wx.showToast({
                title: "请按提示填写数字",
                icon: "none",
                duration: 2e3
            });
            var a = new Array(+n.detail.value).fill({
                content: "?",
                style: "animation: opacity 0.3s ease-in-out;"
            });
            this.setData({
                ranklist: a
            });
        } else if (n.detail.value < 0 || n.detail.value > 100) return void wx.showToast({
            title: "请按提示填写数字",
            icon: "none",
            duration: 2e3
        });
        this.setData(t({}, e, +n.detail.value));
    },
    clickbtn: function() {
        var t = this, e = this;
        if (!this.data.pending) {
            var a = this.data.rank1, i = this.data.rank2, o = this.data.ranklist, r = [];
            if (a >= i) wx.showToast({
                title: "请按提示填写数字",
                icon: "none",
                duration: 2e3
            }); else {
                if (i - a + 1 < this.data.rank3) return console.log(i - a + 1, this.data.rank3), 
                void wx.showToast({
                    title: "请按提示填写数字",
                    icon: "none",
                    duration: 2e3
                });
                this.vibrateShort(), setTimeout(function() {
                    for (var s = function(s) {
                        setTimeout(function() {
                            if (n.globalData.config.useVoice) {
                                var l = wx.createInnerAudioContext();
                                l.src = e.data.result, l.play();
                            }
                            o[s] = {
                                content: t.getUniqueNumber(r, a, i),
                                style: "animation: showanswer cubic-bezier(0,.77,.67,1.43) 0.3s forwards"
                            }, t.setData({
                                ranklist: o
                            }), s === o.length - 1 && t.setData({
                                pending: !1
                            });
                        }, 300 * s);
                    }, l = 0; l < o.length; l++) s(l);
                }, 300), o.forEach(function(t, n) {
                    o[n] = {
                        content: "?",
                        style: "animation: opacity 0.3s ease-in-out;"
                    };
                }), this.setData({
                    ranklist: o,
                    pending: !0
                });
            }
        }
    },
    getUniqueNumber: function(t, n, e) {
        for (var a = this.getRandomArbitrary(n, e); t.indexOf(a) > -1; ) a = this.getRandomArbitrary(n, e);
        return t.push(a), a;
    },
    getRandomArbitrary: function(t, n) {
        return Math.floor(Math.random() * (n - t + 1) + t);
    }
});