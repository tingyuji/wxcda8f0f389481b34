var e = getApp();

Page({
    data: {
        gamelist: [ {
            imgsrc: "/imges/coin.png",
            name: "抛硬币",
            tips: "二选一",
            classname: "coin",
            url: "../coin/coin"
        }, {
            imgsrc: "/imges/dice.png",
            name: "掷骰子",
            tips: "随机数",
            classname: "dice",
            url: "../dice/dice"
        }, {
            imgsrc: "/imges/turnplate.png",
            name: "大转盘",
            tips: "多选一",
            classname: "turnplate",
            url: "../turnplate/turnplate"
        }, {
            imgsrc: "/imges/eatting.png",
            name: "今天吃什么",
            tips: "随机词",
            classname: "eatting",
            url: "../eatting/eatting"
        }, {
            imgsrc: "/imges/sport.png",
            name: "今天运动吗",
            tips: "二选一",
            classname: "sport",
            url: "../sport/sport"
        }, {
            imgsrc: "/imges/random.png",
            name: "随机数生成",
            tips: "随机数",
            classname: "random",
            url: "../random/random"
        } ],
        infos1: "更多实用功能开发中",
        infos2: "拯救选择困难症和纠结患者",
        showUpdate: !1,
        hidden: "hidden"
    },
    bindViewTap: function() {
        wx.redirectTo({
            url: "../logs/logs"
        });
    },
    onLoad: function() {
        try {
            wx.getStorageSync("2020-3-16") || (this.setData({
                showUpdate: !0
            }), wx.setStorage({
                data: !0,
                key: "2020-3-16"
            }));
        } catch (e) {}
    },
    onHide: function() {},
    onShareAppMessage: function() {
        return {
            title: "不要纠结啦，叮咚决策器帮你做决定!",
            imageUrl: "/imges/share-home.png"
        };
    },
    onShareTimeline: function() {
        return {
            title: "不要纠结啦，叮咚决策器帮你做决定!",
            imageUrl: "/imges/share-home.png"
        };
    },
    getUserInfo: function(n) {
        e.globalData.userInfo = n.detail.userInfo, this.setData({
            userInfo: n.detail.userInfo,
            hasUserInfo: !0
        });
    },
    gotoDetail: function(e) {
        var n = e.currentTarget.dataset.url;
        n && wx.navigateTo({
            url: n,
            success: function(e) {},
            fail: function(e) {
                console.log(e);
            }
        });
    },
    gotoDdPhoto: function() {
        wx.navigateToMiniProgram({
            appId: "wx69abccfa61662325",
            path: "pages/index/index",
            success: function(e) {}
        });
    },
    closeModal: function() {
        this.setData({
            showUpdate: !1
        });
    },
    clickModal: function() {}
});