var e = require("../../@babel/runtime/helpers/defineProperty"), t = getApp();

Page({
    data: {
        voice: {
            status: "on",
            show: !0
        },
        shake: {
            status: "on",
            show: !0
        },
        turn: {
            status: "on",
            show: !0
        },
        checkboxItems: [ {
            name: "5:5",
            checked: !1
        }, {
            name: "6:4",
            checked: !0
        }, {
            name: "7:3",
            checked: !1
        } ]
    },
    onLoad: function(e) {
        var a = t.globalData.config;
        if (this.setData({
            navH: t.globalData.navHeight
        }), this.selectComponent("#header").hideheader(), this.animate("#cont", [ {
            top: "33.5%",
            ease: "ease-in-out"
        }, {
            top: "10.5%",
            ease: "ease-in-out"
        } ], 300, function() {}.bind(this)), a) {
            var o = this.data.checkboxItems;
            o.forEach(function(e, t) {
                e.name === a.sportRatio ? e.checked = !0 : e.checked = !1;
            }), this.setData({
                checkboxItems: o,
                voice: {
                    status: a.useVoice ? "on" : "off",
                    show: a.useVoice
                },
                shake: {
                    status: a.useShake ? "on" : "off",
                    show: a.useShake
                },
                turn: {
                    status: a.useCache ? "on" : "off",
                    show: a.useCache
                }
            });
        }
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    save: function() {
        var e = {
            useVoice: this.data.voice.show,
            useShake: this.data.shake.show,
            useCache: this.data.turn.show,
            sportRatio: this.data.checkboxItems.filter(function(e) {
                return e.checked;
            })[0].name
        };
        wx.setStorage({
            data: e,
            key: "config"
        }), t.globalData.config = e;
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    toggle: function(t) {
        var a = t.currentTarget.dataset.type, o = this.data[a];
        o.show ? (o.show = !1, o.status = "off") : (o.show = !0, o.status = "on"), this.setData(e({}, a, o)), 
        this.save();
    },
    setSports: function(e) {
        var t = e.currentTarget.dataset.index, a = this.data.checkboxItems;
        a.forEach(function(e, a) {
            e.checked = t === a;
        }), this.setData({
            checkboxItems: a
        }), this.save();
    }
});