var t = getApp();

Page({
    data: {
        game: {
            name: "叮咚决策器",
            tips: "点击按钮转盘开始，你可以给转盘命名",
            start: "大转盘"
        },
        showDefault: !0,
        turnsrc: "/imges/turnplate/turn1.png",
        turnplatelist: [ {
            id: 0,
            name: "转盘1"
        }, {
            id: 1,
            name: "转盘2"
        }, {
            id: 2,
            name: "转盘3"
        } ],
        templist: [],
        templist2: [],
        pending: !1,
        editlist: [ {
            id: 3,
            class: "active"
        }, {
            id: 4,
            class: ""
        }, {
            id: 5,
            class: ""
        }, {
            id: 6,
            class: ""
        } ],
        showModal: !1,
        turnlength: 3,
        anima_scale: "",
        turnaudio: "https://zm-1253465948.cos.ap-nanjing.myqcloud.com/static/dd/turn.mp3"
    },
    onLoad: function(a) {
        this.setData({
            navH: t.globalData.navHeight,
            config: t.globalData.config
        }), this.selectComponent("#header").hideheader(), null != a && a.origin && this.setData({
            origin: null == a ? void 0 : a.origin
        }), this.animate("#cont", [ {
            top: "33.5%",
            ease: "ease-in-out"
        }, {
            top: "10.5%",
            ease: "ease-in-out"
        } ], 300, function() {}.bind(this));
        for (var e = 3; e < 7; e++) if (!this.data.config.useCache) try {
            wx.removeStorageSync("turn-".concat(e));
        } catch (t) {}
        this.setTurn(this.data.turnlength), t.globalData.config.useVoice && (this.actx_turn = wx.createInnerAudioContext(), 
        this.actx_turn.src = this.data.turnaudio);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.actx_turn && this.actx_turn.stop();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "不要纠结啦，叮咚决策器帮你做决定!",
            imageUrl: "/imges/share-home.png"
        };
    },
    onShareTimeline: function() {
        return {
            title: "不要纠结啦，叮咚决策器帮你做决定!",
            query: "origin=turnplate",
            imageUrl: "/imges/share-home.png"
        };
    },
    vibrateLong: function() {
        this.data.config.useShake && wx.vibrateLong();
    },
    vibrateShort: function() {
        this.data.config.useShake && wx.vibrateShort();
    },
    clearAnimate: function() {
        this.clearAnimation(".turn_default");
    },
    clickbtn: function() {
        var t = this;
        if (!this.data.pending) {
            this.clearAnimate(), this.clearAnimation(".turn_default");
            var a = this.data.turnlength, e = 360 / a, i = Math.floor(Math.random() * a), n = e * i + e / 2;
            this.setData({
                pending: !0
            }), this.vibrateShort(), this.actx_turn && this.actx_turn.play(), this.animate(".turn_default", [ {
                rotate: 0,
                ease: "ease-in-out"
            }, {
                rotate: 3960 + n,
                ease: "ease-in-out"
            } ], 5200, function() {
                var e = t.data.turnplatelist;
                e[i].status = "checked_" + a, t.setData({
                    turnplatelist: e
                }), t.vibrateLong(), setTimeout(function() {
                    e[i].status = "", t.setData({
                        turnplatelist: e,
                        pending: !1
                    });
                }, 2e3);
            });
        }
    },
    selectTurn: function(t) {
        var a = this;
        if (!this.data.pending) {
            this.clearAnimate();
            var e = t.currentTarget.dataset.id, i = this.data.editlist, n = [];
            if ("active" !== i[e].class) {
                if (!this.setTurn(i[e].id)) {
                    for (var s = 0; s < i[e].id; s++) n.push({
                        id: s,
                        name: "转盘" + (s + 1)
                    });
                    this.setData({
                        turnplatelist: n
                    });
                }
                this.animate(".turn_default", [ {
                    scale: [ 1, 1 ],
                    ease: "cubic-bezier(.02,1.04,.69,1.2)"
                }, {
                    scale: [ 1.05, 1.05 ],
                    ease: "cubic-bezier(.02,1.04,.69,1.2)"
                }, {
                    scale: [ 1, 1 ],
                    ease: "cubic-bezier(.02,1.04,.69,1.2)"
                } ], 300, function() {
                    a.clearAnimation(".turn_default");
                }), this.animate(".turn_bg", [ {
                    scale: [ 1, 1 ],
                    ease: "cubic-bezier(.02,1.04,.69,1.2)"
                }, {
                    scale: [ 1.05, 1.05 ],
                    ease: "cubic-bezier(.02,1.04,.69,1.2)"
                }, {
                    scale: [ 1, 1 ],
                    ease: "cubic-bezier(.02,1.04,.69,1.2)"
                } ], 300, function() {
                    a.clearAnimation(".turn_bg");
                }), i.forEach(function(t, a) {
                    t.class = e === a ? "active" : "";
                }), this.setData({
                    editlist: i,
                    turnlength: i[e].id
                });
            }
        }
    },
    setTurn: function(t) {
        try {
            var a = wx.getStorageSync("turn-" + t);
            return !!a && (this.setData({
                turnplatelist: a
            }), !0);
        } catch (t) {
            return !1;
        }
    },
    getTurn: function(t) {},
    editurn: function() {
        if (!this.data.pending) {
            for (var t = this.data.templist, a = this.data.turnlength, e = 0; e < a; e++) t.push({
                id: e,
                name: "转盘" + (e + 1)
            });
            this.setData({
                showModal: !0,
                templist: t,
                templist2: t
            });
        }
    },
    cancel: function() {
        this.setData({
            showModal: !1,
            templist2: [],
            templist: []
        });
    },
    confirm: function() {
        var t = this.data.templist2;
        wx.setStorage({
            data: t,
            key: "turn-" + this.data.turnlength
        }), this.setData({
            turnplatelist: t,
            templist2: [],
            templist: [],
            showModal: !1
        });
    },
    bindKeyInput: function(t) {
        var a = t.detail.value, e = t.currentTarget.dataset.id, i = this.data.templist2;
        i[e].name = a, this.setData({
            templist2: i
        });
    }
});