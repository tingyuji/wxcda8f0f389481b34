var t = require("../../@babel/runtime/helpers/defineProperty"), e = getApp();

Page({
    data: {
        game: {
            name: "叮咚决策器",
            tips: "不知道今天吃啥？点击按钮给你出出主意",
            start: "今天吃什么"
        },
        result: "麻辣香锅",
        status: "start",
        pending: !1,
        current: 1,
        nerbyFoods: [],
        foods: [ "麻辣香锅", "火锅", "串串", "冒菜", "烧烤", "兰州拉面", "沙县小吃", "面食", "刀削面", "盖浇饭", "炒菜", "川菜", "自助餐", "炒面", "炒饭", "西餐", "牛排", "麦当劳", "肯德基", "水饺", "煎饺", "热干面", "牛肉面", "黄焖鸡米饭", "烤肉饭", "鸡公煲", "三明治", "饭团", "馄炖", "卤肉饭", "披萨", "日式料理", "沙拉", "炸鸡", "肉夹馍", "麻辣烫", "简餐盒饭", "粥", "拉面", "石锅拌饭", "烤肉", "咖喱饭", "汤饭套餐", "煲仔饭", "凉皮", "凉面", "肠粉", "意大利面", "鸡排", "烤鸭", "寿司", "面包", "汉堡", "米线", "农家菜", "小碗菜", "韩式料理", "湘菜", "大排档", "羊肉粉", "酸菜鱼", "鸭血粉丝", "烤冷面", "小龙虾", "螺蛳粉", "油焖大虾", "卤味", "瓦罐汤", "过桥米线", "汤包", "包子", "快餐", "中式快餐", "煎饼", "木桶饭", "牛腩煲", "轻食", "汤饭", "烧腊饭", "烤鱼", "麻辣拌", "铁板烧", "汉堡王", "蛋包饭", "油条", "三鲜面", "汤泡面", "吊锅饭", "卷饼", "锅贴", "花甲粉", "炒米粉", "家常菜", "蒸菜", "水果拼盘", "蛋糕", "鸡蛋灌饼", "油泼面", "手抓饼", "蒸饺" ],
        showModal: !1,
        voiceSrc: "https://zm-1253465948.cos.ap-nanjing.myqcloud.com/static/dd/eatting.mp3",
        resultSrc: "https://zm-1253465948.cos.ap-nanjing.myqcloud.com/static/dd/result.mp3",
        location: null
    },
    onLoad: function(t) {
        try {
            var a = wx.getStorageSync("lastSelect");
            console.log(a), 0 === a ? this.setData({
                current: 0
            }) : 1 === a && this.setData({
                current: 1
            });
        } catch (t) {}
        this.setData({
            navH: e.globalData.navHeight,
            config: e.globalData.config
        }), null != t && t.origin && this.setData({
            origin: null == t ? void 0 : t.origin
        }), this.selectComponent("#header").hideheader(), this.animate("#cont", [ {
            top: "33.5%",
            ease: "ease-in-out"
        }, {
            top: "10.5%",
            ease: "ease-in-out"
        } ], 300, function() {}.bind(this)), e.globalData.config.useVoice && (this.actx = wx.createInnerAudioContext(), 
        this.actx.src = this.data.voiceSrc, this.actx_result = wx.createInnerAudioContext(), 
        this.actx_result.src = this.data.resultSrc);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "不知道吃什么？我帮你参谋参谋",
            imageUrl: "/imges/share-eat.png"
        };
    },
    onShareTimeline: function() {
        return {
            title: "不知道吃什么？我帮你参谋参谋",
            query: "origin=packet",
            imageUrl: "/imges/share-eat.png"
        };
    },
    vibrateLong: function() {
        this.data.config.useShake && wx.vibrateLong();
    },
    vibrateShort: function() {
        this.data.config.useShake && wx.vibrateShort();
    },
    clickbtn: function() {
        var e = this, a = this, n = a.data, o = n.pending, s = n.current, i = n.foods, c = n.nerbyFoods, r = n.mks;
        o || (this.vibrateShort(), this.setData(t({
            status: "ques",
            pending: !0
        }, "game.start", "换一个")), a.actx && a.actx.play(), setTimeout(function() {
            var t = [];
            console.log(s, r), 0 === s && r ? t = c : (e.setData({
                current: 1
            }), t = i);
            var n = Math.floor(Math.random() * t.length);
            0 === s && r && e.setData({
                location: r[n]
            }), a.actx_result && a.actx_result.play(), e.vibrateLong(), e.setData({
                status: "answer",
                result: t[n] || "火锅",
                pending: !1
            });
        }, 2100));
    },
    sourceSelect: function(t) {
        var e = this, a = t.target.dataset.id, n = e.data.current;
        if (a && n != a) {
            switch (this.setData({
                status: "middle"
            }), parseInt(a, 10)) {
              case 0:
                n = 0;
                break;

              case 1:
                n = 1;
                break;

              default:
                n = 1;
            }
            setTimeout(function() {
                e.setData({
                    status: "start"
                });
            }, 0), wx.setStorage({
                data: n,
                key: "lastSelect"
            }), e.setData({
                current: n
            });
        }
    },
    openConfirm: function() {
        wx.showModal({
            content: "检测到您没打开此小程序的定位权限，是否去设置打开？",
            confirmText: "确认",
            cancelText: "取消",
            success: function(t) {
                console.log(t), t.confirm ? (console.log("用户点击确认"), wx.openSetting({
                    success: function(t) {}
                })) : console.log("用户点击取消");
            }
        });
    },
    getAuth: function() {
        var t = this;
        this.data.location;
        wx.getSetting({
            success: function(e) {
                e.authSetting["scope.userLocation"] ? wx.getLocation({
                    type: "gcj02",
                    success: function(e) {
                        t.getList({
                            latitude: e.latitude,
                            longitude: e.longitude
                        });
                    }
                }) : wx.authorize({
                    scope: "scope.userLocation",
                    success: function() {
                        wx.getLocation({
                            type: "gcj02",
                            success: function(e) {
                                t.getList({
                                    latitude: e.latitude,
                                    longitude: e.longitude
                                });
                            }
                        });
                    },
                    fail: function() {
                        console.log("用户已经拒绝位置授权"), t.openConfirm();
                    }
                });
            }
        });
    },
    getList: function(t) {},
    toggleModal: function() {
        var t = this.data, e = t.status, a = t.showModal;
        "start" !== e && this.setData({
            showModal: !a
        });
    },
    switchtoEle: function(t) {
        this.data.result;
        wx.navigateToMiniProgram({
            appId: "wxece3a9a4c82f58c9",
            path: "pages/sharePid/web/index?scene=https%3A%2F%2Ftb.ele.me%2Fwow%2Fz%2Fele-ad%2Fssr%2Fadsearch%3Fspm%3Da2ogi.20933402.search.1%26spm-url%3Da2ogi.20933402.search.1%26activityIdentity%3DTAOKE_WECHAT_NEW_SEARCH%26result%3D%257B%257D%26meta%3D%257B%2522resultListPath%2522%253A%2522.%2522%257D%26directE%3D-s029EVRX74mfqpbXCIbiT4HLbAgwKUU4ZaqhZ1SHgthdTBDolXtS1tI7uF4BIhjHI5KddWxMhadguwZotOdcSWCovFv25DuALj4VFCbiPHsGjMno9kzIJ4hzN7Paf1MCwUyJk5MLLRx4B5RrJWldNiZ3lLpEAnXcSh4J074vx7XVAfXCdjFt0i1T8VAymApPELraxZlNo4Rh13T9f61EbhAgnjg0zSbOEY7wfMlvjyuylCOjNRGjbNNnzQPstQrAS1EvttgyU7FgDRiRhhd7uuaFec1hTcYaTWrKU25wGCCVikNaP30DKYdGTJyHwirL3zIBtwdd1FZm2eIJfPm2wT8Qq4elMs50dqTbnmfpoGOvGAvuLkPtIgwdfZcEW3ACvhCwV1cXZtalYvCdlQQBUMZs3yALclg26Q3gar6GHUQ3nEWnMLAS4hPQeb4R%26unionLens%3DlensId%25253AAPP%2525401647444317%2525402107f9b4_087d_17f93555357_0414%25254001%25253BeventPageId%25253A20150318020002192%26pid%3Dmm_2465640171_2590750365_111933000349%26es%3DNg5i1f%25252F9%25252F9Vt3vqbdXnGlk%25252BUfz9f9P2yJ9NdXOqx%25252BSwDdyxS9Plm%25252FEsi1ev%25252BwNDodB%25252BT0uY9FVs%25253D%26udf_temp_store%3D%257B%257D%26lensId%3DOPT%25401647757284%25402132a594_087b_17fa5fcd416_c8a3%254001%26scene%3DRAdEiZu%26alsc_exsrc%3DES0000008947~~shortCode~RAdEiZu%26ruleKey%3DWECHAT_MINIPROGRAM_LAYOUT%26trackMap%3D%257B%2522bucketId%2522%253A%2522290724%2522%257D%26ruleBranch%3D130003-290724&startTime=1647757287340"
        });
    },
    switchtoMeit: function() {
        var t = this.data.result;
        wx.navigateToMiniProgram({
            appId: "wx2c348cf579062e56",
            path: "/packages/index/search/search?keyword=".concat(t)
        });
    },
    toPacket: function() {
        wx.navigateTo({
            url: "../packet/packet"
        });
    },
    gotoMap: function() {
        var t = this.data, e = t.location;
        t.result;
        wx.openLocation({
            latitude: e.latitude,
            longitude: e.longitude,
            name: e.title,
            address: "距离".concat(e.distance, "米 ").concat(e.address),
            success: function(t) {}
        });
    }
});